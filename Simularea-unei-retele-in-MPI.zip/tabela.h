typedef struct tabela_rutare{

	int source;
	int destination;
	
}tabela_rutare;
