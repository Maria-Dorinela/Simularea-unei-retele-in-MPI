typedef struct message{

	int source_node;
	char destination_node;
	char msg[];
	
}message;
