#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "mpi.h"
#include <unistd.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <err.h>
#include "tabela_etapa_2.h"
#include <ctype.h>
#include "mesaj.h"
 

int main(int argc, char** argv) {
	
	FILE *file_table, *file_message;//fisierul cu tabelele de rutare
	tabela_rutare_2 *table;//tabela de rutare
	message *Msg;//mesajele care trebuiesc trimise
	int Id, N_sursa, N_dest;//variabile pentru citire din fisier a tabelei de rutare
	int nr_line_file, i,j,nr_line_file_msg;
	MPI_Status status;
	int size, rank;//numarul proceselor si id

	file_table = fopen("tabela_e2", "r");//deschid fisierul pentru citire
	fscanf(file_table,"%d ",&nr_line_file);//citesc numarul de linii din fisier
	printf("Numarul de linii din fisier este: %d\n", nr_line_file);//afisare numar linii din fisier
	table = malloc(nr_line_file * sizeof(tabela_rutare_2));//alocare memorie pentru tabela de rutare

	i = 0;//contor
	//citire linii din fisier si popularae tabelei de rutare
	while(!feof(file_table)){
		fscanf(file_table,"%d %d %d",&Id, &N_sursa, &N_dest);
		table[i].id = Id;//id procesului
		table[i].source = N_sursa;//nodul sursa
		table[i].destination = N_dest;//nodul destinatie
		i++;
		//printf("%d %d %d\n", Id, N_sursa, N_dest);
	}
	fclose(file_table);//inchid fisierul

	file_message = fopen("file2", "r");//deschid fisierul pentru citire mesaje
	fscanf(file_message,"%d ",&nr_line_file_msg);//citire numaru de linii din fisierul cu mesaje
	//printf("Numarul de linii din fisier este: %d\n", nr_line_file_msg);
	Msg = malloc(nr_line_file_msg * sizeof(message));//alocare memorie pentru structura cu mesaje

	int ns;
	char nd;
	char m[10];	
	j = 0;
	/*while(!feof(file_message)){
		fscanf(file_table,"%d %c %10s",&ns, &nd, &m);
		Msg[j].source_node = ns;
		Msg[j].destination_node = nd;
		for(i = 0; i < 10; i++){
			Msg[j].msg[i] = m[i];
		}
		j++;
		printf("%d %c %s\n", ns, nd, m);
	}
	fclose(file_message);*/
	
	// initializari
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
	printf("Acum PROCESUL: %d\n", rank);
	int de_la = 0;//nodul sursa pentru trimitrea unui mesaj
	int la = 2;//nodul destinatie pentru trimiterea unui mesaj
	char M[10] = "Hello!";//mesajul trimis
	int confirmare = 1;//variabila pentru confirmare
	printf("Nodul sursa este: %d\n", de_la);
	printf("Nodul destinatie este: %d\n", la);
	printf("Mesajul de trimis este: %s\n", M);
	
	//daca id-ul procesului corespunde cu nodul sursa
	if(rank == de_la){	
		printf("Sunt procesul %d, eu trebuie sa trimis mesajul\n", rank);
		//parcurg tabbela de rutare
		for(i = 0;i < nr_line_file; i++){
			//ma duc acolo unde id nodul sursa este acelas cu campul "id" din tabela de rutare
			if(de_la == table[i].id){
				//initial nu am primit nici o confirmare, deoarece nu am trimis niciun mesaj
				int receive_confirmare = 0;
				MPI_Send(&M, 1, MPI_CHAR, table[i].destination, 1, MPI_COMM_WORLD);//trimit mesajul nodului asociat din tabela de rutare 
				MPI_Recv(&receive_confirmare,1,MPI_INT,MPI_ANY_SOURCE,1,MPI_COMM_WORLD,&status);//receptionez confirmari de la nodurile destinatie

				if(receive_confirmare == 1)//daca am primit confirmarea afisez un mesaj si variabila devine din nou 0
					printf("Am primit confirmarea! Mesajul a fost trimis cu succes\n");
				receive_confirmare = 0;

				printf("Sunt %d, am primit de la %d, mesajul: %s\n", table[i].destination, rank, M);

				if(table[i].destination == la){//daca nodul din tabela corespunde nodului destinatie afisez un mesaj ca este destinatarul
					printf("Eu sunt destinatarul!!!!!\n");
					//trimit mesaj de confirmare catre sursa
					MPI_Send(&confirmare, 1, MPI_INT, rank, 1, MPI_COMM_WORLD); 
				}
				else{//daca nu sunt destinatarul acestui mesaj
					printf("Sunt %d si nu sunt destinatarul acestiu mesaj, Trimit mai departe\n", table[i].destination);
					//parcurg din nou tabela de rutare si trimit mesaje mai departe pana ajung la destinatar
					for(j = 0; j < nr_line_file; j++){

						if(table[j].id == table[i].destination){//daca sunt pe id corespunzator
								//trimit mesajul
								MPI_Send(&M, 1, MPI_CHAR, table[j].destination, 1, MPI_COMM_WORLD);
								receive_confirmare = 0;//momentan nu am confirmare
								//primesc confirmari
								MPI_Recv(&receive_confirmare,1,MPI_INT,MPI_ANY_SOURCE,1,MPI_COMM_WORLD,&status);

								if(receive_confirmare == 1)	//daca am primit o confirmare inseamna ca mesajul a ajuns la destinatar	
									printf("Am primit confirmarea! Mesajul a fost trimis cu succes\n");
								receive_confirmare = 0;	//confirmare devine din nou 0	
 
								printf("Sunt %d, am primit de la %d, mesajul: %s\n", table[j].destination, table[i].destination, M);
								if(table[j].destination == la){//daca mesajul a ajuns la destinatar
									//afisez un mesaj
									printf("Eu sunt destinatarul!!!!!\n");
									//trimit confirmarea la sursa
									MPI_Send(&confirmare, 1, MPI_INT, table[i].destination, 1, MPI_COMM_WORLD); 
								}
								
						}
					}
				}
			}
	
		}
	}






	
}
