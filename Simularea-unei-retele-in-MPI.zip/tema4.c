#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "mpi.h"
#include <unistd.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <err.h>
#include "tabela.h"
#include "mesaj.h"
#include <ctype.h>
 

int main(int argc, char** argv) {

    int rank, size,i,j,x,m,n,o,p,t1,t2,l,ll,y,yy;//variabile
	int dim;
    MPI_Status status;
	MPI_Request request;

	FILE *file_in_data, *file_in_msg, *file_out1;//fisiere de intrare si iesire
	file_in_msg = fopen(argv[2], "r");//deschid fisierul de intrare pentru citire(al doilea parametru)

	//Fisierul cu mesaje
	int msg_number;//numarul de mesaje care trebuiesc trimise intre noduri
	message *Msg;//structura care contine mesajele de trimis(sursa, destinatie, mesaj)
	
	fscanf(file_in_msg,"%i",&msg_number);//citire numarul de mesaje ce trebuiesc trimise
	printf("Numarul de mesaje care trebuiesc trimise este: %i\n", msg_number);

	Msg = malloc(msg_number * sizeof(message));//alocare memorie pentr mesaje

	char *code;
	int lala;
	int nn = 0;
	code = malloc(1000);
	while((lala = fgetc(file_in_msg)) != EOF){
		code[nn++] = (char)lala;
	}
	for(i = 0; i < nn; i ++){
		
		printf("%c", code[i]);

	}
	
	
    // initializari
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

	/*int matrix[12][12] = {{0,1,1,0,0,0,0,0,0,0,0,0},
					  {0,0,0,1,1,1,1,0,0,0,0,0},
				      {1,0,0,0,0,0,0,1,1,0,0,0},
					  {0,1,0,0,0,0,0,0,0,0,0,0},
					  {0,1,0,0,0,0,0,0,0,1,1,0},
					  {0,1,0,0,0,0,0,0,0,0,0,0},
					  {0,1,0,0,0,0,0,0,0,0,0,0},
					  {0,0,1,0,0,0,0,0,0,0,0,0},
					  {0,0,1,0,0,0,0,0,0,0,0,1},
					  {0,0,0,0,1,0,0,0,0,0,0,0},
					  {0,0,0,0,1,0,0,0,0,0,0,0},
					  {0,0,0,0,0,0,0,0,1,0,0,0}};*/

	//matrice de adiacenta a grafului
	int matrix[6][6] = {{0,1,1,0,0,0}, {0,0,0,1,1,0}, {1,0,0,0,0,1}, {0,1,0,0,0,0}, {0,1,0,0,0,0}, {0,0,1,0,0,0}};

	int lista_adiacenta[size];//lista de adiacenta specifica fiecarui nod
	for(m = 0; m < size; m++){//initializare vector lista_adiacenta cu 0
		lista_adiacenta[m] = 0;
	}
	
	//fiecare thread va citeste din fisier linia cu lista de adiacenta care ii apartine

	int sondaj = 1, parent = -1, children_number = 0, buffer = 0;
	tabela_rutare *table, *table_receive;
	
	if(rank == 0){//daca procesulare id 0
		children_number = 0;
		y = 0;
		table = malloc(20 * sizeof(tabela_rutare));//alocare zona memorie pentru tabela de rutare

		//parcurg matricea si trimit mesajede sondaj la copii
		for(i = 0; i < size; i++){
			if(matrix[0][i] == 1){

				//trimit mesaje de sondaj la copii si completez tabela de rutare
				MPI_Send(&sondaj, 1, MPI_INT, i, 1, MPI_COMM_WORLD);  			
				children_number ++;

				//populare tabela rutare 
				table[y] .source = rank;
				table[y].destination = i;
				y++;

    		}
		}
		printf("Sunt %d si am %d copii\n", rank, children_number);
		
		table_receive = malloc(20 * sizeof(tabela_rutare));//alocare memorie pentru tabela rutare primita de la copii
		yy = y;
		//nodul 0 primeste tabelele de rutare de la copii
		for(j = 0; j < size; j++){
			if(matrix[0][j] == 1){
				
				//primire tabel rutare de la copii
				MPI_Recv(&table_receive,sizeof(table_receive),MPI_INT,j,1,MPI_COMM_WORLD,&status);

				//verificare tabele de rutare si update
						for(t1 = 0; t1 < y; t1++){
							for(t2 = 0; t2 < sizeof(table_receive); t2++){
								//daca sursa din tabela unui nod parinte nu corespunde cu destinatia din tabela copilului atunci adaug acel element din tabela copilului in tabela parintelui
								if(table[t1].source != table_receive[t2].destination){
										table[yy].source = table_receive[t2].source;
										table[yy].destination = table_receive[t2].destination;
										yy++;
								}
							}
						}
			}
		}
	}
	else{//daca procesul nu are id 0
		
		MPI_Request *r;
		parent = 0;
		children_number = 0;
		int leaf = 1;//variabila in care retin daca un nod este sau nu frunza
		
		table = malloc(20 * sizeof(tabela_rutare));//alocare memorie tabela de rutare

		int sondaj_recv;//varibila pentru retinerea unui mesaj de tipul sondaj
		l = 0;

		//primesc sondaj
		MPI_Recv(&sondaj_recv,1,MPI_INT,MPI_ANY_SOURCE,1,MPI_COMM_WORLD,&status);
		parent = status.MPI_SOURCE;//aflare parinte(susa de la care am primit mesajul)
		printf("Sunt procesul: %d , parintele meu este:  %d\n",rank,parent);

		//tabela de rutare initiala a fiecariu nod(nod sursa = el insusi, nod destinatie = copii si parinte)
		for(i = 0; i < size; i++){

			if(matrix[rank][i] == 1){
              	table[l].source = rank;
				table[l].destination =i;
				l++;
			}

		}
		//trimit sondaj mai departe la copii inafara de parinte
		for (i = 0; i <	size; i++){
				if(matrix[i][rank]!=0 && i!=parent){
					//trimitere mesaj de tipulsondaj
					MPI_Send(&sondaj_recv, 1, MPI_INT, i, 1, MPI_COMM_WORLD);
					children_number ++;//numarul de copii
					leaf = 0;
					
				}
		}

		
		printf("Sunt %d si am %d copii\n", rank, children_number);
		for(i = 0; i < children_number + 1; i++){
			printf("%d: %d --- %d\n", rank, table[i].source, table[i].destination);
		}

		

		//daca nodul e frunza atunci trimit tabela de rutare catre parinte
		if(leaf == 1){
			//afisare mesaj
			printf("%d - Sunt frunza!!!!.Trimit tabela rutare!\n",rank);
			MPI_Send(&table, l * sizeof(tabela_rutare), MPI_INT, parent, 1, MPI_COMM_WORLD);
			
			for(m = 0; m < l; m++)
							printf("Sunt %d si trimit tabela: %d --- %d la parinte %d\n", rank, table[m].source, table[m].destination, parent);
			
			
		}
		//altfel astept tabelele de rutare de la copii 
		else{
			printf("%d - Nu sunt frunza!!!!\n",rank);
			table_receive = malloc(10 * sizeof(tabela_rutare));//alocare memorie pentru tabela de rutare primita de la copii
			for(i = 0; i < size; i++){

				//daca e copil primesc tabela de rutare de la el
				if(matrix[rank][i] == 1 && i != parent){
						MPI_Recv(&table_receive,sizeof(table_receive),MPI_INT,i,1,MPI_COMM_WORLD,&status);

						//verificare tabele de rutare si update
						ll = l;
						for(t1 = 0; t1 < l; t1++){
							for(t2 = 0; t2 < sizeof(table_receive); t2++){
								//daca sursa din tabela unui nod parinte nu corespunde cu destinatia din tabela copilului atunci adaug acel element din tabela copilului in tabela parintelui
								if(table[t1].source != table_receive[t2].destination){
										table[ll].source = table_receive[t2].source;
										table[ll].destination = table_receive[t2].destination;
										ll++;
								}
								
							}
						}
					
				}

			}

			MPI_Send(&table, l * sizeof(tabela_rutare), MPI_INT, parent, 1, MPI_COMM_WORLD);
			
		}
	}

	//scriere tabele de rutare in fisier
	file_out1 = fopen("iesire1.txt", "a");
	
	for(i = 0; i < sizeof(table); i++){
		
		if(sizeof(table) != 0){
			fprintf(file_out1, "%i ", rank);
			fprintf(file_out1, "%i ", table[i].source);
			fprintf(file_out1, "%i ", table[i].destination);
			fprintf(file_out1, "\n");
		}
	}
	fclose(file_out1);

	printf("FINALA ETAPA 1!!!!!!!!!!!!!!\n\n");

}

