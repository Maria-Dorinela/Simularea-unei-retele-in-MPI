typedef struct tabela_rutare_2{

	int id;
	int source;
	int destination;
	
}tabela_rutare_2;
